<?php
// Debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Koneksi database
include '../../config/koneksi.php';

// Validasi parameter kode
if (!isset($_GET['kode']) || empty($_GET['kode'])) {
    die("Error: Parameter 'kode' tidak ditemukan!");
}
$kode_nip = trim(mysqli_real_escape_string($koneksi, $_GET['kode']));
$kode_nip = str_replace(" ", "", $kode_nip); // Hapus spasi tambahan

// Query data kenaikan pangkat
$sql_kp = "
    SELECT kp.*, p.nama 
    FROM tb_kp kp
    INNER JOIN tb_pegawai p ON kp.nip = p.nip
    WHERE kp.nip = '$kode_nip'
";
$query_kp = mysqli_query($koneksi, $sql_kp);

// Debug query
if (!$query_kp) {
    die("Error Query: " . mysqli_error($koneksi));
}

// Validasi data
if (mysqli_num_rows($query_kp) == 0) {
    die("Error: Data kenaikan pangkat tidak ditemukan untuk NIP: " . $kode_nip);
}
$data_kp = mysqli_fetch_array($query_kp, MYSQLI_BOTH);
?>

<div class="card">
    <div class="card-header">
        <h3>Detail Kenaikan Pangkat</h3>
    </div>
    <div class="card-body">
        <table class="table table-striped">
            <tr>
                <td><b>NIP</b></td>
                <td>: <?php echo htmlspecialchars($data_kp['nip']); ?></td>
            </tr>
            <tr>
                <td><b>Nama Pegawai</b></td>
                <td>: <?php echo htmlspecialchars($data_kp['nama']); ?></td>
            </tr>
            <tr>
                <td><b>Terhitung Mulai Tanggal</b></td>
                <td>: <?php echo htmlspecialchars($data_kp['TMT']); ?></td>
            </tr>
            <tr>
                <td><b>Masa Kerja Tahun</b></td>
                <td>: <?php echo htmlspecialchars($data_kp['masa_kerja_tahun']); ?> Tahun</td>
            </tr>
            <tr>
                <td><b>Masa Kerja Bulan</b></td>
                <td>: <?php echo htmlspecialchars($data_kp['masa_kerja_bulan']); ?> Bulan</td>
            </tr>
        </table>
        <a href="?page=data-kp" class="btn btn-warning">
