<div class="card card-info">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa fa-table"></i> Data Kenaikan Pangkat</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <div class="table-responsive">
            <div>
                <a href="?page=add-kp" class="btn btn-primary">
                    <i class="fa fa-edit"></i> Tambah Data</a>
            </div>
            <br>
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>NIP</th>
                        <th>Nama Pegawai</th>
                        <th>Terhitung Mulai Tanggal</th>
                        <th>Masa Kerja Tahun</th>
                        <th>Masa Kerja Bulan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    // Query JOIN untuk menampilkan data kenaikan pangkat
                    $sql = $koneksi->query("
                        SELECT kp.*, p.nama 
                        FROM tb_kp kp 
                        INNER JOIN tb_pegawai p ON kp.nip = p.nip
                    ");

                    while ($data = $sql->fetch_assoc()) {
                    ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($data['nip']); ?></td>
                            <td><?php echo htmlspecialchars($data['nama']); ?></td>
                            <td><?php echo htmlspecialchars($data['TMT']); ?></td>
                            <td><?php echo htmlspecialchars($data['masa_kerja_tahun']); ?> Tahun</td>
                            <td><?php echo htmlspecialchars($data['masa_kerja_bulan']); ?> Bulan</td>
                            <td>
                                <!-- Tombol Action View -->
                                <a href="?page=view-kp&kode=<?php echo urlencode($data['nip']); ?>" 
                                   title="Detail" class="btn btn-info btn-sm">
                                    <i class="fa fa-eye"></i>
                                </a>
                                <!-- Tombol Edit -->
                                <a href="?page=edit-kp&kode=<?php echo urlencode($data['nip']); ?>" 
                                   title="Ubah" class="btn btn-success btn-sm">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <!-- Tombol Delete -->
                                <a href="?page=del-kp&kode=<?php echo urlencode($data['nip']); ?>" 
                                   onclick="return confirm('Apakah anda yakin hapus data ini?')" 
                                   title="Hapus" class="btn btn-danger btn-sm">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
