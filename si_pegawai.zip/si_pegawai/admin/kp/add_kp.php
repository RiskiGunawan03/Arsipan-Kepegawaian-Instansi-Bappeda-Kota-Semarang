<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa fa-edit"></i> Tambah Data</h3>
    </div>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="card-body">

            <div class="form-group row">
                <label class="col-sm-2 col-form-label">NIP</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="nip" name="nip" placeholder="NIP" required>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Nama Pegawai</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama Pegawai" required>
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Terhitung Mulai Tanggal</label>
                <div class="col-sm-5">
                    <input type="date" class="form-control" id="TMT" name="TMT" placeholder="Terhitung Mulai Tanggal"
                        required>
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Masa Kerja Tahun</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="mkt" name="mkt" placeholder="Masa Kerja Tahun" required>
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-2 col-form-label">Masa Kerja Bulan</label>
                <div class="col-sm-5">
                    <input type="text" class="form-control" id="mkb" name="mkb" placeholder="Masa Kerja Bulan" required>
                </div>
            </div>



        </div>
        <div class="card-footer">
            <input type="submit" name="Simpan" value="Simpan" class="btn btn-info">
            <a href="?page=data-kp" title="Kembali" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>

<?php
if (isset($_POST['Simpan'])) {
    // Ambil data input
    $nip = mysqli_real_escape_string($koneksi, $_POST['nip']);
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $TMT = mysqli_real_escape_string($koneksi, $_POST['TMT']);
    $masa_kerja_tahun = mysqli_real_escape_string($koneksi, $_POST['mkt']);
    $masa_kerja_bulan = mysqli_real_escape_string($koneksi, $_POST['mkb']);

    // Validasi apakah NIP ada di tabel tb_pegawai
    $query_check = mysqli_query($koneksi, "SELECT * FROM tb_pegawai WHERE nip = '$nip'");
    if (mysqli_num_rows($query_check) == 0) {
        echo "<script>
            alert('Error: NIP tidak ditemukan di tabel pegawai!');
            window.location.href = '?page=add-kp';
        </script>";
        exit;
    }

    // Query INSERT ke tabel tb_kp (tidak termasuk kolom nama)
    $sql_simpan = "INSERT INTO tb_kp (nip, nama, TMT, masa_kerja_tahun, masa_kerja_bulan) 
                   VALUES ('$nip','$nama', '$TMT', '$masa_kerja_tahun', '$masa_kerja_bulan')";
    $query_simpan = mysqli_query($koneksi, $sql_simpan);

    if ($query_simpan) {
        echo "<script>
            alert('Data berhasil disimpan!');
            window.location.href = '?page=data-kp';
        </script>";
    } else {
        echo "<script>
            alert('Error: Data gagal disimpan. " . mysqli_error($koneksi) . "');
            window.location.href = '?page=add-kp';
        </script>";
    }
}
?>
