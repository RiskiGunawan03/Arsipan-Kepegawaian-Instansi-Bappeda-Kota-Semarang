<?php
include "../inc/koneksi.php";

$nip = $_GET['nip'];

// Ambil data profil
$sql_cek = "SELECT * FROM tb_profil";
$query_cek = mysqli_query($koneksi, $sql_cek);
$data_cek = mysqli_fetch_array($query_cek, MYSQLI_BOTH);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Data Pegawai</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        h1, h2, h3 {
            text-align: center;
        }
        img {
            width: 150px;
            height: auto;
        }
    </style>
</head>
<body>
    <h1>CETAK DATA PEGAWAI</h1>
    <center>
        <h2><?php echo htmlspecialchars($data_cek['nama_profil']); ?></h2>
        <h3><?php echo htmlspecialchars($data_cek['alamat']); ?></h3>
        <hr size="2px" color="black">
    </center>

    <?php
    // Ambil data pegawai dan data kenaikan pangkat
    $sql_tampil = "SELECT p.*, kp.TMT, kp.masa_kerja_tahun, kp.masa_kerja_bulan 
                   FROM tb_pegawai p 
                   LEFT JOIN tb_kp kp ON p.nip = kp.nip 
                   WHERE p.nip='$nip'";
    $query_tampil = mysqli_query($koneksi, $sql_tampil);

    if (mysqli_num_rows($query_tampil) > 0) {
        while ($data = mysqli_fetch_array($query_tampil, MYSQLI_BOTH)) {
            // Inisialisasi data kenaikan pangkat
            $tanggal_mulai = !empty($data['TMT']) ? $data['TMT'] : 'Tidak Ada';
            $tahun_kerja = !empty($data['masa_kerja_tahun']) ? $data['masa_kerja_tahun'] : 0;
            $bulan_kerja = !empty($data['masa_kerja_bulan']) ? $data['masa_kerja_bulan'] : 0;
    ?>

    <center>
        <h4><u>DATA PEGAWAI</u></h4>
    </center>
    <table>
        <tbody>
            <tr>
                <td>NIP</td>
                <td>:</td>
                <td><?php echo htmlspecialchars($data['nip']); ?></td>
                <td rowspan="6" align="center">
                    <img src="../foto/<?php echo htmlspecialchars($data['foto']); ?>" alt="Foto Pegawai">
                </td>
            </tr>
            <tr>
                <td>Nama</td>
                <td>:</td>
                <td><?php echo htmlspecialchars($data['nama']); ?></td>
            </tr>
            <tr>
                <td>Golongan</td>
                <td>:</td>
                <td><?php echo htmlspecialchars($data['golongan']); ?></td>
            </tr>
            <tr>
                <td>Pangkat</td>
                <td>:</td>
                <td><?php echo htmlspecialchars($data['pangkat']); ?></td>
            </tr>
            <tr>
                <td>Status</td>
                <td>:</td>
                <td><?php echo htmlspecialchars($data['status']); ?></td>
            </tr>
            <tr>
                <td>Jabatan</td>
                <td>:</td>
                <td><?php echo htmlspecialchars($data['jabatan']); ?></td>
            </tr>
        </tbody>
    </table>

    <center>
        <h4><u>DATA KENAIKAN PANGKAT</u></h4>
    </center>
    <table>
        <tbody>
            <tr>
                <td>NIP</td>
                <td>:</td>
                <td><?php echo htmlspecialchars($data['nip']); ?></td>
            </tr>
            <tr>
                <td>Nama Pegawai</td>
                <td>:</td>
                <td><?php echo htmlspecialchars($data['nama']); ?></td>
            </tr>
            <tr>
                <td>Terhitung Mulai Tanggal</td>
                <td>:</td>
                <td><?php echo htmlspecialchars($tanggal_mulai); ?></td>
            </tr>
            <tr>
                <td>Masa Kerja (Tahun)</td>
                <td>:</td>
                <td><?php echo htmlspecialchars($tahun_kerja); ?> Tahun</td>
            </tr>
            <tr>
                <td>Masa Kerja (Bulan)</td>
                <td>:</td>
                <td><?php echo htmlspecialchars($bulan_kerja); ?> Bulan</td>
            </tr>
        </tbody>
    </table>

    <?php 
        }
    } else {
        echo "<center><h3>Data tidak ditemukan untuk NIP: $nip</h3></center>";
    }
    ?>

    <script>
        window.print();
    </script>
</body>
</html>
